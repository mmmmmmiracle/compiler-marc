package lexer;

public class TokenVal {
  // fields
    public int linenum;
    public int charnum;
  // constructor
    public TokenVal(int line, int ch) {
        linenum = line;
        charnum = ch;
    }	
}