package symtable;

public class EmptySymTableException extends RuntimeException {

}
