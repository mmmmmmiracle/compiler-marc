package lexer;

public class CharNum {
    public static int num=1;
}
