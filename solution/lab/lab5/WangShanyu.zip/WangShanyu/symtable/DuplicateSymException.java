package symtable;

public class DuplicateSymException extends RuntimeException {

}
