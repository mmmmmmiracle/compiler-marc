package lexer;

/**
 * A tiny class to handle the position of the current character
 */
public class CharNum {

    public static int num=1;
    
}
